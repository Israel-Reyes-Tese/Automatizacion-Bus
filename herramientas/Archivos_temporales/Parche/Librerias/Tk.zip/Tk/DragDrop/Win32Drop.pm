package Tk::DragDrop::Win32Drop;
# Dummy placeholder for symetry

use vars qw($VERSION);
$VERSION = '4.004'; # $Id: //depot/Tkutf8/DragDrop/Win32Site/Win32Drop.pm#4 $

use Tk ();
1;
